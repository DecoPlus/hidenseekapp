# Bújócska időzítő

Modern, teljes képernyős Windows-játékmester alkalmazás öt egyedi játékmóddal,
visszaszámlálóval, zenei lejátszási listával és az életben lévő játékosok
számlálásával.

## Fő funkciók

- prémium, sötét TM Pizza-stílusú felület lekerekített panelekkel;
- öt eltérő hangulatú és feliratú játékmód:
  - **Classic Hideout** – az eredeti bújócska;
  - **Reactor Meltdown** – instabil reaktormag és kritikus visszaszámlálás;
  - **EMP aktiváció** – elektromágneses töltés és impulzus;
  - **Total Blackout** – vészvilágításos, elsötétült létesítmény;
  - **Facility Lockdown** – lezárt ajtók és maximális biztonsági szint;
- óra, perc, másodperc és induló játékosszám beállítása;
- több MP3, WAV vagy WMA zene, átrendezés és véletlen sorrend;
- módonként eltérő animált indítás, játékképernyő és eredményképernyő;
- teljes képernyős játéknézet;
- a játékképernyőn az idő és az életben lévő játékosok kapják a főszerepet;
- külön szünet- és eredményképernyő;
- kikapcsolható mozgó effektek gyengébb gépekhez;
- eseményvezérelt, kímélő időzítő és WebView2-megjelenítés;
- a beállítások automatikus megjegyzése.

## Irányítás játék közben

| Billentyű | Művelet |
|---|---|
| `SPACE` | Egy játékos kiesett |
| `Backspace` | Az utolsó kiesés visszavonása |
| `P` | Szünet / folytatás, a zenével együtt |
| `Esc` | Játék leállítása és vissza a vezérlőpulthoz |
| `Enter` | Eredményképernyőről vissza a vezérlőpulthoz |

## EXE készítése Windowson

1. Telepítsd a Python 3-at a [python.org](https://www.python.org/downloads/)
   oldalról. Telepítéskor pipáld be az **Add Python to PATH** lehetőséget.
2. Csomagold ki ezt a ZIP-et.
3. Kattints duplán a `BUILD_EXE.bat` fájlra.
4. Az elkészült program itt lesz:
   `dist\BujocskaIdozito\BujocskaIdozito.exe`

A stabilabb indulás miatt a program mappás kiadásként készül el. Másik gépre a
teljes `dist\BujocskaIdozito` mappát másold át, ne csak az EXE-t. A felülethez
a Microsoft Edge WebView2 Runtime szükséges, amely a naprakész Windows 10/11
rendszereken általában már telepítve van.

## Futtatás EXE építése nélkül

Kattints duplán a `RUN.bat` fájlra. Első futtatáskor a fájl telepíti a szükséges
Python-csomagokat.

## Megjegyzés a zenéhez

A zenelejátszás a Windows saját médiarendszerét használja. Az MP3 és WAV
formátum a legbiztosabb. A zenék nem kerülnek bele az EXE-be; a program a
kiválasztott fájlok eredeti helyét jegyzi meg.
