@echo off
setlocal
cd /d "%~dp0"

set "PY_CMD=py -3"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=python"

%PY_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo HIBA: A Python 3 nincs telepitve.
    echo Toltsd le innen: https://www.python.org/downloads/
    echo Telepiteskor pipald be: Add Python to PATH
    echo.
    pause
    exit /b 1
)

echo.
echo [1/2] A szukseges csomagok telepitese...
%PY_CMD% -m pip install --upgrade -r requirements.txt
if errorlevel 1 goto :build_error

echo.
echo [2/2] Stabil BujocskaIdozito csomag epitese...
%PY_CMD% -m PyInstaller ^
    --noconfirm ^
    --clean ^
    --onedir ^
    --noupx ^
    --windowed ^
    --name BujocskaIdozito ^
    --icon "assets\icon.ico" ^
    --add-data "ui;ui" ^
    --add-data "assets;assets" ^
    --exclude-module PyQt5 ^
    --exclude-module PyQt6 ^
    --exclude-module PySide2 ^
    --exclude-module PySide6 ^
    --exclude-module cefpython3 ^
    app.py
if errorlevel 1 goto :build_error

echo.
echo KESZ!
echo Az alkalmazas itt talalhato:
echo %CD%\dist\BujocskaIdozito\BujocskaIdozito.exe
echo.
echo FONTOS: masik gepre a teljes BujocskaIdozito mappat masold at.
echo.
explorer "%CD%\dist\BujocskaIdozito"
pause
exit /b 0

:build_error
echo.
echo HIBA: Az EXE epitese nem sikerult.
echo Masold ki a fenti hibauzenetet, es kuldd el nekem.
echo.
pause
exit /b 1
