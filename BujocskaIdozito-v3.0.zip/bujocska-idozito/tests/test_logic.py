import importlib.util
import sys
import types
import unittest
from pathlib import Path


webview_stub = types.ModuleType("webview")
webview_stub.Window = object
sys.modules.setdefault("webview", webview_stub)

APP_PATH = Path(__file__).resolve().parents[1] / "app.py"
SPEC = importlib.util.spec_from_file_location("bujocska_app", APP_PATH)
APP = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(APP)


class SettingsTests(unittest.TestCase):
    def test_defaults(self):
        data = APP.sanitize_settings({})
        self.assertEqual(data["minutes"], 10)
        self.assertEqual(data["seconds"], 59)
        self.assertEqual(data["players"], 12)
        self.assertEqual(data["mode"], "classic")
        self.assertTrue(data["effects"])

    def test_limits(self):
        data = APP.sanitize_settings(
            {
                "hours": 88,
                "minutes": -4,
                "seconds": 999,
                "players": 0,
                "volume": 300,
            }
        )
        self.assertEqual(data["hours"], 23)
        self.assertEqual(data["minutes"], 0)
        self.assertEqual(data["seconds"], 59)
        self.assertEqual(data["players"], 1)
        self.assertEqual(data["volume"], 100)

    def test_zero_duration_is_corrected(self):
        data = APP.sanitize_settings(
            {"hours": 0, "minutes": 0, "seconds": 0}
        )
        self.assertEqual(data["minutes"], 10)

    def test_duplicate_music_is_removed(self):
        data = APP.sanitize_settings({"music": ["a.mp3", "a.mp3", "b.wav"]})
        self.assertEqual(data["music"], ["a.mp3", "b.wav"])

    def test_mode_and_effects_are_sanitized(self):
        selected = APP.sanitize_settings(
            {"mode": "reactor", "effects": False}
        )
        invalid = APP.sanitize_settings({"mode": "not-a-real-mode"})
        self.assertEqual(selected["mode"], "reactor")
        self.assertFalse(selected["effects"])
        self.assertEqual(invalid["mode"], "classic")


if __name__ == "__main__":
    unittest.main()
