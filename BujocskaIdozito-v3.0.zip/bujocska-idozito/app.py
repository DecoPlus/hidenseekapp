from __future__ import annotations

import ctypes
import json
import os
import platform
import random
import sys
import threading
import time
from pathlib import Path
from typing import Any

import webview


APP_NAME = "Bújócska időzítő"
APP_VERSION = "3.0.0"
MUSIC_ALIAS = "bujocska_idozito_music"
VALID_MODES = {"classic", "reactor", "emp", "blackout", "lockdown"}


def app_data_dir() -> Path:
    base = os.getenv("APPDATA")
    if base:
        return Path(base) / "BujocskaIdozito"
    return Path.home() / ".bujocska_idozito"


def settings_path() -> Path:
    return app_data_dir() / "settings.json"


def legacy_settings_path() -> Path:
    base = os.getenv("APPDATA")
    if base:
        return Path(base) / "HajszaTimer" / "settings.json"
    return Path.home() / ".hajsza_timer" / "settings.json"


def resource_path(relative: str) -> Path:
    bundle = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return bundle / relative


def default_settings() -> dict[str, Any]:
    return {
        "hours": 0,
        "minutes": 10,
        "seconds": 59,
        "players": 12,
        "mode": "classic",
        "effects": True,
        "shuffle": False,
        "volume": 80,
        "music": [],
    }


def sanitize_settings(raw: Any) -> dict[str, Any]:
    defaults = default_settings()
    data = raw if isinstance(raw, dict) else {}

    def number(name: str, minimum: int, maximum: int) -> int:
        try:
            value = int(data.get(name, defaults[name]))
        except (TypeError, ValueError):
            value = int(defaults[name])
        return max(minimum, min(maximum, value))

    music = data.get("music", [])
    if not isinstance(music, list):
        music = []
    unique_music: list[str] = []
    for item in music:
        if isinstance(item, str) and item and item not in unique_music:
            unique_music.append(item)

    mode = data.get("mode", defaults["mode"])
    if mode not in VALID_MODES:
        mode = defaults["mode"]

    result = {
        "hours": number("hours", 0, 23),
        "minutes": number("minutes", 0, 59),
        "seconds": number("seconds", 0, 59),
        "players": number("players", 1, 999),
        "mode": mode,
        "effects": bool(data.get("effects", defaults["effects"])),
        "shuffle": bool(data.get("shuffle", defaults["shuffle"])),
        "volume": number("volume", 0, 100),
        "music": unique_music,
    }
    if result["hours"] + result["minutes"] + result["seconds"] == 0:
        result["minutes"] = 10
    return result


class SettingsStore:
    def load(self) -> dict[str, Any]:
        candidates = (settings_path(), legacy_settings_path())
        for path in candidates:
            try:
                return sanitize_settings(
                    json.loads(path.read_text(encoding="utf-8"))
                )
            except (OSError, json.JSONDecodeError, TypeError):
                continue
        return default_settings()

    def save(self, raw: Any) -> dict[str, Any]:
        data = sanitize_settings(raw)
        path = settings_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(".tmp")
            temporary.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            os.replace(temporary, path)
        except OSError:
            pass
        return data


class WindowsPlaylist:
    """Looping Windows playlist powered by the built-in MCI media service."""

    def __init__(self) -> None:
        self.files: list[str] = []
        self.shuffle = False
        self.volume = 80
        self.current_index = -1
        self._bag: list[int] = []
        self._open = False
        self._paused = False
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        self._poll_thread: threading.Thread | None = None
        self.available = platform.system() == "Windows"
        self._mci = None
        if self.available:
            try:
                self._mci = ctypes.windll.winmm.mciSendStringW
            except Exception:
                self.available = False

    def _send(self, command: str, result_size: int = 512) -> tuple[int, str]:
        if not self.available or self._mci is None:
            return 1, ""
        result = ctypes.create_unicode_buffer(result_size)
        error = self._mci(command, result, result_size, 0)
        return int(error), result.value.strip()

    def configure(self, settings: dict[str, Any]) -> None:
        with self._lock:
            self.close()
            self.files = [
                path
                for path in settings.get("music", [])
                if isinstance(path, str) and Path(path).is_file()
            ]
            self.shuffle = bool(settings.get("shuffle", False))
            self.volume = max(0, min(100, int(settings.get("volume", 80))))
            self.current_index = -1
            self._bag = []

    def _next_index(self) -> int:
        if not self.files:
            return -1
        if not self.shuffle:
            return (self.current_index + 1) % len(self.files)
        if not self._bag:
            self._bag = list(range(len(self.files)))
            random.shuffle(self._bag)
            if (
                len(self._bag) > 1
                and self.current_index >= 0
                and self._bag[-1] == self.current_index
            ):
                self._bag[0], self._bag[-1] = self._bag[-1], self._bag[0]
        return self._bag.pop()

    def _close_media(self) -> None:
        if self._open:
            self._send(f"stop {MUSIC_ALIAS}")
            self._send(f"close {MUSIC_ALIAS}")
        self._open = False
        self._paused = False

    def _play_index(self, index: int, failed_attempts: int = 0) -> bool:
        if index < 0 or index >= len(self.files):
            return False
        self._close_media()
        path = self.files[index]
        error, _ = self._send(f'open "{path}" alias {MUSIC_ALIAS}')
        self.current_index = index
        if error:
            if failed_attempts + 1 < len(self.files):
                return self._play_index(
                    self._next_index(), failed_attempts + 1
                )
            return False
        self._open = True
        self._send(f"setaudio {MUSIC_ALIAS} volume to {self.volume * 10}")
        error, _ = self._send(f"play {MUSIC_ALIAS} from 0")
        if error:
            self._close_media()
            if failed_attempts + 1 < len(self.files):
                return self._play_index(
                    self._next_index(), failed_attempts + 1
                )
            return False
        self._paused = False
        return True

    def start(self) -> bool:
        with self._lock:
            if not self.files:
                return True
            if not self.available:
                return False
            self._stop_event = threading.Event()
            started = self._play_index(self._next_index())
            if started:
                self._poll_thread = threading.Thread(
                    target=self._poll_loop,
                    args=(self._stop_event,),
                    name="BujocskaMusicPoll",
                    daemon=True,
                )
                self._poll_thread.start()
            return started

    def _poll_loop(self, stop_event: threading.Event) -> None:
        while not stop_event.wait(0.55):
            with self._lock:
                if not self._open or self._paused:
                    continue
                error, mode = self._send(f"status {MUSIC_ALIAS} mode")
                if not error and mode.lower() == "stopped":
                    self._play_index(self._next_index())

    def pause(self) -> None:
        with self._lock:
            if self._open and not self._paused:
                self._send(f"pause {MUSIC_ALIAS}")
                self._paused = True

    def resume(self) -> None:
        with self._lock:
            if self._open and self._paused:
                self._send(f"resume {MUSIC_ALIAS}")
                self._paused = False

    def close(self) -> None:
        with self._lock:
            self._stop_event.set()
            self._close_media()


class AppApi:
    def __init__(self) -> None:
        self.store = SettingsStore()
        self.player = WindowsPlaylist()
        self.window: webview.Window | None = None
        self.session_settings = default_settings()
        self._fullscreen = False
        self._lock = threading.RLock()

    def attach(self, window: webview.Window) -> None:
        with self._lock:
            self.window = window

    def load_settings(self) -> dict[str, Any]:
        return self.store.load()

    def choose_music(self) -> list[str]:
        if self.window is None:
            return []
        dialog_kind = (
            webview.FileDialog.OPEN
            if hasattr(webview, "FileDialog")
            else webview.OPEN_DIALOG
        )
        result = self.window.create_file_dialog(
            dialog_kind,
            allow_multiple=True,
            file_types=(
                "Zenefájlok (*.mp3;*.wav;*.wma)",
                "MP3 (*.mp3)",
                "WAV (*.wav)",
                "WMA (*.wma)",
            ),
        )
        return list(result or [])

    def prepare_session(self, raw_settings: Any) -> dict[str, Any]:
        settings = self.store.save(raw_settings)
        with self._lock:
            self.session_settings = settings
        self.player.configure(settings)
        self._set_fullscreen(True)
        return settings

    def start_music(self) -> dict[str, Any]:
        return {
            "ok": self.player.start(),
            "has_music": bool(self.player.files),
        }

    def pause_music(self) -> bool:
        self.player.pause()
        return True

    def resume_music(self) -> bool:
        self.player.resume()
        return True

    def finish_music(self) -> bool:
        self.player.close()
        return True

    def exit_session(self) -> bool:
        self.player.close()
        self._set_fullscreen(False)
        return True

    def _set_fullscreen(self, enabled: bool) -> None:
        with self._lock:
            if self.window is None or self._fullscreen == enabled:
                return
            window = self.window
            self._fullscreen = enabled
        try:
            window.toggle_fullscreen()
        except Exception:
            with self._lock:
                self._fullscreen = not enabled

    def shutdown(self, *_args: Any) -> None:
        self.player.close()


def main() -> None:
    index = resource_path("ui/index.html")
    api = AppApi()
    window = webview.create_window(
        APP_NAME,
        url=str(index),
        js_api=api,
        width=1280,
        height=800,
        min_size=(980, 680),
        resizable=True,
        background_color="#050505",
        text_select=False,
        zoomable=False,
    )
    api.attach(window)
    window.events.closed += api.shutdown
    webview.start(
        gui="edgechromium",
        http_server=True,
        debug=False,
        private_mode=True,
        icon=str(resource_path("assets/icon.ico")),
    )


if __name__ == "__main__":
    main()
