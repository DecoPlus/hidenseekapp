"use strict";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const MODES = {
  classic: {
    code: "PROFILE 01",
    name: "CLASSIC",
    subname: "ORIGINAL",
    kicker: "TM PIZZA ORIGINAL",
    heroLine1: "CLASSIC",
    heroLine2: "HIDEOUT.",
    description:
      "A letisztult, eredeti bújócska mód. Az idő fogy, a játékosok pedig egyesével tűnnek el.",
    status: "JÁTÉK FOLYAMATBAN",
    timerCaption: "HÁTRALÉVŐ IDŐ",
    aliveTop: "ÉLETBEN LÉVŐ",
    aliveBottom: "JÁTÉKOSOK",
    introEyebrow: "A JÁTÉK HAMAROSAN INDUL",
    introFinal: "INDULJ!",
    pauseEyebrow: "A JÁTÉK MEGÁLLÍTVA",
    hazardLeft: "SYS // NOMINAL",
    hazardRight: "TM-01",
    startLabel: "JÁTÉK INDÍTÁSA",
    captureToast: "EGY JÁTÉKOS KIESETT",
    endStatus: "MENET VÉGE",
    endTime: "LEJÁRT AZ IDŐ.",
    endCaught: "MINDENKI KIESETT.",
    remainingText: "maradt az órán",
  },
  reactor: {
    code: "PROFILE 02",
    name: "REACTOR",
    subname: "MELTDOWN",
    kicker: "CRITICAL EVENT PROTOCOL",
    heroLine1: "REACTOR",
    heroLine2: "MELTDOWN.",
    description:
      "A reaktormag instabil. A visszaszámlálás végén bekövetkezik az összeomlás — addig kell túlélni.",
    status: "MAGINSTABILITÁS",
    timerCaption: "MAGÖSSZEOMLÁSIG",
    aliveTop: "BENT MARADT",
    aliveBottom: "SZEMÉLYZET",
    introEyebrow: "REAKTOR-VÉSZPROTOKOLL INDUL",
    introFinal: "KRITIKUS!",
    pauseEyebrow: "REAKTORFOLYAMAT FELFÜGGESZTVE",
    hazardLeft: "CORE // UNSTABLE",
    hazardRight: "TEMP CRITICAL",
    startLabel: "MELTDOWN INDÍTÁSA",
    captureToast: "SZEMÉLYZETI JEL ELVESZETT",
    endStatus: "KRITIKUS ESEMÉNY",
    endTime: "MAGÖSSZEOMLÁS.",
    endCaught: "SZEMÉLYZET KIÜRÍTVE.",
    remainingText: "maradt a mag összeomlásáig",
  },
  emp: {
    code: "PROFILE 03",
    name: "EMP",
    subname: "AKTIVÁCIÓ",
    kicker: "ELECTROMAGNETIC PROTOCOL",
    heroLine1: "EMP",
    heroLine2: "AKTIVÁCIÓ.",
    description:
      "Az elektromágneses impulzus töltődik. A kijelző instabil, a jelek sorban eltűnnek a hálózatról.",
    status: "IMPULZUS TÖLTŐDIK",
    timerCaption: "EMP AKTIVÁLÁSIG",
    aliveTop: "AKTÍV",
    aliveBottom: "JELEK",
    introEyebrow: "KONDENZÁTOROK TÖLTÉSE",
    introFinal: "ONLINE",
    pauseEyebrow: "EMP-TÖLTÉS FELFÜGGESZTVE",
    hazardLeft: "FIELD // CHARGING",
    hazardRight: "PULSE 03",
    startLabel: "EMP TÖLTÉS INDÍTÁSA",
    captureToast: "EGY JEL ELTŰNT",
    endStatus: "IMPULZUS ESEMÉNY",
    endTime: "EMP AKTIVÁLVA.",
    endCaught: "MINDEN JEL ELTŰNT.",
    remainingText: "maradt az impulzusig",
  },
  blackout: {
    code: "PROFILE 04",
    name: "BLACKOUT",
    subname: "VÉSZÜZEM",
    kicker: "EMERGENCY POWER ONLY",
    heroLine1: "TOTAL",
    heroLine2: "BLACKOUT.",
    description:
      "A főhálózat leállt. Csak a vészvilágítás és a túlélők gyenge jelei maradtak aktívak.",
    status: "HÁLÓZAT OFFLINE",
    timerCaption: "VÉSZENERGIA HÁTRA",
    aliveTop: "ÉSZLELT",
    aliveBottom: "TÚLÉLŐK",
    introEyebrow: "FŐHÁLÓZAT LEKAPCSOLÁSA",
    introFinal: "SÖTÉTSÉG",
    pauseEyebrow: "VÉSZENERGIA MEGŐRZÉSE",
    hazardLeft: "GRID // OFFLINE",
    hazardRight: "AUX 12%",
    startLabel: "BLACKOUT INDÍTÁSA",
    captureToast: "EGY ÉLETJEL ELTŰNT",
    endStatus: "ÁRAMELLÁTÁSI ESEMÉNY",
    endTime: "TELJES BLACKOUT.",
    endCaught: "NINCS TÖBB ÉLETJEL.",
    remainingText: "maradt a vészenergiából",
  },
  lockdown: {
    code: "PROFILE 05",
    name: "FACILITY",
    subname: "LOCKDOWN",
    kicker: "SECURITY LEVEL MAXIMUM",
    heroLine1: "FACILITY",
    heroLine2: "LOCKDOWN.",
    description:
      "Az objektum minden kijárata lezárva. A biztonsági rendszer a bent maradt játékosokat követi.",
    status: "OBJEKTUM LEZÁRVA",
    timerCaption: "ZÁR FELOLDÁSÁIG",
    aliveTop: "SZABADON MOZGÓ",
    aliveBottom: "JÁTÉKOSOK",
    introEyebrow: "BIZTONSÁGI ZÁRAK AKTIVÁLÁSA",
    introFinal: "LEZÁRVA",
    pauseEyebrow: "LOCKDOWN FOLYAMAT FELFÜGGESZTVE",
    hazardLeft: "SECURITY // LEVEL 5",
    hazardRight: "DOORS SEALED",
    startLabel: "LOCKDOWN INDÍTÁSA",
    captureToast: "CÉLPONT FELTARTÓZTATVA",
    endStatus: "BIZTONSÁGI ESEMÉNY",
    endTime: "ZÁR FELOLDVA.",
    endCaught: "MINDENKI FELTARTÓZTATVA.",
    remainingText: "maradt a zár feloldásáig",
  },
};

const defaults = {
  hours: 0,
  minutes: 10,
  seconds: 59,
  players: 12,
  mode: "classic",
  effects: true,
  shuffle: false,
  volume: 80,
  music: [],
};

const els = {
  adminScreen: $("#adminScreen"),
  gameScreen: $("#gameScreen"),
  modeButtons: $$(".mode-option"),
  profileKicker: $("#profileKicker"),
  modeHeroLine1: $("#modeHeroLine1"),
  modeHeroLine2: $("#modeHeroLine2"),
  modeHeroDescription: $("#modeHeroDescription"),
  selectedModeLabel: $("#selectedModeLabel"),
  hours: $("#hoursInput"),
  minutes: $("#minutesInput"),
  seconds: $("#secondsInput"),
  players: $("#playersInput"),
  shuffle: $("#shuffleInput"),
  effects: $("#effectsInput"),
  volume: $("#volumeInput"),
  volumeValue: $("#volumeValue"),
  playlist: $("#playlist"),
  playlistEmpty: $("#playlistEmpty"),
  addMusic: $("#addMusicButton"),
  playerMinus: $("#playerMinus"),
  playerPlus: $("#playerPlus"),
  start: $("#startButton"),
  startLabel: $("#startButton > span"),
  summary: $("#launchSummary"),
  error: $("#formError"),
  gameModeCode: $("#gameModeCode"),
  gameModeName: $("#gameModeName"),
  gameStatus: $("#gameStatus"),
  timerCaption: $("#timerCaption"),
  timer: $("#timerDisplay"),
  progress: $("#progressBar"),
  hazardLeft: $("#hazardLeft"),
  hazardRight: $("#hazardRight"),
  aliveLabelTop: $("#aliveLabelTop"),
  aliveLabelBottom: $("#aliveLabelBottom"),
  alive: $("#aliveCount"),
  aliveCard: $("#aliveCard"),
  captureFlash: $("#captureFlash"),
  captureToast: $("#captureToast"),
  intro: $("#introOverlay"),
  introCode: $("#introCode"),
  introEyebrow: $("#introEyebrow"),
  introCount: $("#introCount"),
  pause: $("#pauseOverlay"),
  pauseEyebrow: $("#pauseEyebrow"),
  end: $("#endOverlay"),
  endStatus: $("#endStatus"),
  endTitle: $("#endTitle"),
  endSubtitle: $("#endSubtitle"),
  endBack: $("#endBackButton"),
  bridgeWarning: $("#bridgeWarning"),
};

const state = {
  settings: { ...defaults },
  playlist: [],
  durationMs: 0,
  remainingMs: 0,
  deadline: 0,
  totalPlayers: 12,
  alivePlayers: 12,
  running: false,
  paused: false,
  ended: false,
  gameVisible: false,
  spaceDown: false,
  tickTimer: 0,
  lastShownSecond: null,
  introToken: 0,
  warningTimer: 0,
};

function hasBridge() {
  return Boolean(window.pywebview && window.pywebview.api);
}

function showBridgeWarning() {
  window.clearTimeout(state.warningTimer);
  els.bridgeWarning.classList.add("show");
  state.warningTimer = window.setTimeout(
    () => els.bridgeWarning.classList.remove("show"),
    5200,
  );
}

async function apiCall(method, args = [], options = {}) {
  if (!hasBridge() || typeof window.pywebview.api[method] !== "function") {
    return { ok: false, value: null, unavailable: true };
  }

  const timeout = options.timeout ?? 3500;
  let timeoutId = 0;
  try {
    const nativeCall = Promise.resolve(window.pywebview.api[method](...args));
    if (timeout <= 0) {
      return { ok: true, value: await nativeCall };
    }

    const timeoutCall = new Promise((resolve) => {
      timeoutId = window.setTimeout(
        () => resolve({ __bridgeTimeout: true }),
        timeout,
      );
    });
    const value = await Promise.race([nativeCall, timeoutCall]);
    window.clearTimeout(timeoutId);
    if (value && value.__bridgeTimeout) {
      if (options.warn) showBridgeWarning();
      return { ok: false, value: null, timeout: true };
    }
    return { ok: true, value };
  } catch (error) {
    window.clearTimeout(timeoutId);
    console.error(`Háttérfolyamat-hiba (${method})`, error);
    if (options.warn) showBridgeWarning();
    return { ok: false, value: null, error: true };
  }
}

function clamp(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function baseName(path) {
  return String(path).split(/[\\/]/).pop() || path;
}

function formatTime(milliseconds) {
  const totalSeconds = Math.max(0, Math.ceil(milliseconds / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) {
    return [hours, minutes, seconds]
      .map((value) => String(value).padStart(2, "0"))
      .join(":");
  }
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function selectedMode() {
  return MODES[state.settings.mode] || MODES.classic;
}

function selectMode(modeKey, animate = true) {
  const key = MODES[modeKey] ? modeKey : "classic";
  const mode = MODES[key];
  state.settings.mode = key;
  document.body.dataset.mode = key;

  els.modeButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.mode === key);
  });
  els.profileKicker.innerHTML = `<i></i> ${mode.kicker}`;
  els.modeHeroLine1.textContent = mode.heroLine1;
  els.modeHeroLine2.textContent = mode.heroLine2;
  els.modeHeroDescription.textContent = mode.description;
  els.selectedModeLabel.textContent = `${mode.name} / ${mode.subname}`;
  els.startLabel.textContent = mode.startLabel;

  els.gameModeCode.textContent = mode.code;
  els.gameModeName.textContent = `${mode.name} / ${mode.subname}`;
  els.gameStatus.textContent = mode.status;
  els.timerCaption.textContent = mode.timerCaption;
  els.hazardLeft.textContent = mode.hazardLeft;
  els.hazardRight.textContent = mode.hazardRight;
  els.aliveLabelTop.textContent = mode.aliveTop;
  els.aliveLabelBottom.textContent = mode.aliveBottom;
  els.captureToast.textContent = mode.captureToast;
  els.introCode.textContent = `${mode.code} // ${mode.name}`;
  els.introEyebrow.textContent = mode.introEyebrow;
  els.pauseEyebrow.textContent = mode.pauseEyebrow;
  els.endStatus.textContent = mode.endStatus;

  if (animate) {
    const targets = [els.modeHeroLine1, els.modeHeroLine2, els.modeHeroDescription];
    targets.forEach((element) => {
      element.animate(
        [
          { opacity: 0.25, transform: "translateY(5px)" },
          { opacity: 1, transform: "translateY(0)" },
        ],
        { duration: 260, easing: "cubic-bezier(.2,.8,.2,1)" },
      );
    });
  }
}

function readForm() {
  const settings = {
    hours: clamp(els.hours.value, 0, 23, 0),
    minutes: clamp(els.minutes.value, 0, 59, 0),
    seconds: clamp(els.seconds.value, 0, 59, 0),
    players: clamp(els.players.value, 1, 999, 1),
    mode: MODES[state.settings.mode] ? state.settings.mode : "classic",
    effects: Boolean(els.effects.checked),
    shuffle: Boolean(els.shuffle.checked),
    volume: clamp(els.volume.value, 0, 100, 80),
    music: [...state.playlist],
  };
  settings.duration =
    settings.hours * 3600 + settings.minutes * 60 + settings.seconds;
  return settings;
}

function applySettings(settings) {
  const clean = { ...defaults, ...(settings || {}) };
  els.hours.value = clamp(clean.hours, 0, 23, 0);
  els.minutes.value = clamp(clean.minutes, 0, 59, 10);
  els.seconds.value = clamp(clean.seconds, 0, 59, 59);
  els.players.value = clamp(clean.players, 1, 999, 12);
  els.shuffle.checked = Boolean(clean.shuffle);
  els.effects.checked = clean.effects !== false;
  els.volume.value = clamp(clean.volume, 0, 100, 80);
  state.playlist = Array.isArray(clean.music)
    ? [...new Set(clean.music.filter((item) => typeof item === "string" && item))]
    : [];
  state.settings = { ...defaults, ...clean };
  selectMode(clean.mode || "classic", false);
  document.body.classList.toggle("effects-off", !els.effects.checked);
  renderPlaylist();
  updateFormSummary();
}

function showError(message) {
  els.error.textContent = message;
  els.error.classList.toggle("visible", Boolean(message));
}

function updateFormSummary() {
  const settings = readForm();
  els.hours.value = settings.hours;
  els.minutes.value = settings.minutes;
  els.seconds.value = settings.seconds;
  els.players.value = settings.players;
  els.volumeValue.textContent = `${settings.volume}%`;
  els.summary.textContent =
    `${formatTime(settings.duration * 1000)} • ${settings.players} játékos • ${selectedMode().name}`;
  document.body.classList.toggle("effects-off", !settings.effects);
  if (settings.duration > 0) showError("");
}

function iconButton(icon, label, className, handler) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = className || "";
  button.title = label;
  button.setAttribute("aria-label", label);
  button.innerHTML = icon;
  button.addEventListener("click", handler);
  return button;
}

function renderPlaylist() {
  els.playlist.replaceChildren();
  if (state.playlist.length === 0) {
    els.playlist.appendChild(els.playlistEmpty);
    els.playlistEmpty.hidden = false;
    return;
  }

  state.playlist.forEach((path, index) => {
    const row = document.createElement("div");
    row.className = "playlist-row";
    row.style.animationDelay = `${Math.min(index * 30, 180)}ms`;

    const number = document.createElement("span");
    number.className = "playlist-index";
    number.textContent = String(index + 1).padStart(2, "0");

    const name = document.createElement("span");
    name.className = "playlist-name";
    name.textContent = baseName(path);
    name.title = path;

    const actions = document.createElement("div");
    actions.className = "playlist-actions";
    const up = iconButton(
      '<svg viewBox="0 0 24 24"><path d="m6 15 6-6 6 6"></path></svg>',
      "Feljebb",
      "",
      () => moveTrack(index, -1),
    );
    const down = iconButton(
      '<svg viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"></path></svg>',
      "Lejjebb",
      "",
      () => moveTrack(index, 1),
    );
    const remove = iconButton(
      '<svg viewBox="0 0 24 24"><path d="M5 5l14 14M19 5 5 19"></path></svg>',
      "Eltávolítás",
      "remove",
      () => removeTrack(index),
    );
    up.disabled = index === 0;
    down.disabled = index === state.playlist.length - 1;
    actions.append(up, down, remove);
    row.append(number, name, actions);
    els.playlist.appendChild(row);
  });
}

function moveTrack(index, direction) {
  const target = index + direction;
  if (target < 0 || target >= state.playlist.length) return;
  [state.playlist[index], state.playlist[target]] = [
    state.playlist[target],
    state.playlist[index],
  ];
  renderPlaylist();
}

function removeTrack(index) {
  state.playlist.splice(index, 1);
  renderPlaylist();
}

async function chooseMusic() {
  els.addMusic.disabled = true;
  const result = await apiCall("choose_music", [], { timeout: 0 });
  els.addMusic.disabled = false;
  if (!result.ok || !Array.isArray(result.value) || result.value.length === 0) {
    return;
  }
  state.playlist = [...new Set([...state.playlist, ...result.value])];
  renderPlaylist();
}

function switchScreen(target) {
  [els.adminScreen, els.gameScreen].forEach((screen) => {
    screen.classList.toggle("active", screen === target);
  });
  state.gameVisible = target === els.gameScreen;
}

function wait(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

async function playIntro() {
  const token = ++state.introToken;
  const mode = selectedMode();
  els.intro.classList.add("active");
  els.intro.setAttribute("aria-hidden", "false");
  const frames = [
    ["3", 500],
    ["2", 500],
    ["1", 500],
    [mode.introFinal, 700],
  ];
  for (const [text, duration] of frames) {
    if (token !== state.introToken) return false;
    els.introCount.textContent = text;
    els.introCount.classList.remove("pop");
    void els.introCount.offsetWidth;
    els.introCount.classList.add("pop");
    await wait(duration);
  }
  if (token !== state.introToken) return false;
  els.intro.classList.remove("active");
  els.intro.setAttribute("aria-hidden", "true");
  return true;
}

async function startGame() {
  const settings = readForm();
  if (settings.duration <= 0) {
    showError("A játékidő nem lehet 00:00.");
    return;
  }
  showError("");
  els.start.disabled = true;
  state.settings = { ...settings };
  selectMode(settings.mode, false);

  state.durationMs = settings.duration * 1000;
  state.remainingMs = state.durationMs;
  state.totalPlayers = settings.players;
  state.alivePlayers = settings.players;
  state.running = false;
  state.paused = false;
  state.ended = false;
  state.spaceDown = false;
  state.lastShownSecond = null;
  window.clearInterval(state.tickTimer);

  els.timer.textContent = formatTime(state.durationMs);
  els.progress.style.transform = "scaleX(1)";
  els.alive.textContent = String(state.alivePlayers);
  els.end.classList.remove("active");
  els.pause.classList.remove("active");
  switchScreen(els.gameScreen);

  const preparation = apiCall("prepare_session", [settings], {
    timeout: 3500,
    warn: true,
  });
  const introFinished = await playIntro();
  await preparation;
  els.start.disabled = false;
  if (!introFinished || !state.gameVisible) return;

  void apiCall("start_music", [], { timeout: 1800, warn: true });
  state.deadline = performance.now() + state.durationMs;
  state.running = true;
  renderGameTime();
  state.tickTimer = window.setInterval(gameTick, 100);
}

function gameTick() {
  if (!state.gameVisible || !state.running || state.paused || state.ended) return;
  state.remainingMs = Math.max(0, state.deadline - performance.now());
  renderGameTime();
  if (state.remainingMs <= 0) finishGame("time");
}

function renderGameTime() {
  const shown = Math.max(0, Math.ceil(state.remainingMs / 1000));
  if (state.lastShownSecond !== shown) {
    state.lastShownSecond = shown;
    els.timer.textContent = formatTime(state.remainingMs);
    if (
      state.settings.mode === "emp" &&
      state.settings.effects &&
      shown > 0 &&
      shown % 7 === 0
    ) {
      els.timer.classList.remove("glitch");
      void els.timer.offsetWidth;
      els.timer.classList.add("glitch");
    }
  }
  const ratio = Math.max(0, Math.min(1, state.remainingMs / state.durationMs));
  els.progress.style.transform = `scaleX(${ratio})`;
}

function animateCapture() {
  els.alive.classList.remove("bump");
  els.aliveCard.classList.remove("hit");
  els.captureFlash.classList.remove("active");
  els.captureToast.classList.remove("show");
  void els.alive.offsetWidth;
  els.alive.classList.add("bump");
  els.aliveCard.classList.add("hit");
  els.captureFlash.classList.add("active");
  els.captureToast.classList.add("show");
}

function catchPlayer() {
  if (!state.running || state.paused || state.ended || state.alivePlayers <= 0) {
    return;
  }
  state.alivePlayers -= 1;
  els.alive.textContent = String(state.alivePlayers);
  animateCapture();
  if (state.alivePlayers <= 0) {
    window.setTimeout(() => finishGame("caught"), 270);
  }
}

function undoCatch() {
  if (
    !state.running ||
    state.paused ||
    state.ended ||
    state.alivePlayers >= state.totalPlayers
  ) {
    return;
  }
  state.alivePlayers += 1;
  els.alive.textContent = String(state.alivePlayers);
  els.alive.animate(
    [
      { transform: "translateY(6px)", color: "var(--good)", opacity: 0.55 },
      { transform: "translateY(0)", color: "var(--text)", opacity: 1 },
    ],
    { duration: 300, easing: "cubic-bezier(.2,.8,.2,1)" },
  );
}

function togglePause() {
  if (!state.running || state.ended) return;
  if (state.paused) {
    state.paused = false;
    state.deadline = performance.now() + state.remainingMs;
    els.pause.classList.remove("active");
    els.pause.setAttribute("aria-hidden", "true");
    void apiCall("resume_music", [], { timeout: 1200 });
  } else {
    state.remainingMs = Math.max(0, state.deadline - performance.now());
    state.paused = true;
    els.pause.classList.add("active");
    els.pause.setAttribute("aria-hidden", "false");
    void apiCall("pause_music", [], { timeout: 1200 });
  }
}

function finishGame(reason) {
  if (state.ended) return;
  const mode = selectedMode();
  state.running = false;
  state.paused = false;
  state.ended = true;
  window.clearInterval(state.tickTimer);
  void apiCall("finish_music", [], { timeout: 1200 });

  if (reason === "caught") {
    els.endTitle.textContent = mode.endCaught;
    els.endSubtitle.textContent =
      `${formatTime(state.remainingMs)} ${mode.remainingText}.`;
  } else {
    els.endTitle.textContent = mode.endTime;
    els.endSubtitle.textContent =
      state.alivePlayers === 1
        ? "1 játékos maradt életben."
        : `${state.alivePlayers} játékos maradt életben.`;
  }
  els.end.classList.add("active");
  els.end.setAttribute("aria-hidden", "false");
}

function exitGame() {
  if (!state.gameVisible) return;
  ++state.introToken;
  state.running = false;
  state.paused = false;
  state.ended = false;
  state.spaceDown = false;
  window.clearInterval(state.tickTimer);
  [els.intro, els.pause, els.end].forEach((overlay) => {
    overlay.classList.remove("active");
    overlay.setAttribute("aria-hidden", "true");
  });
  switchScreen(els.adminScreen);
  void apiCall("exit_session", [], { timeout: 1800, warn: true });
}

function createStars() {
  const container = $("#stars");
  const fragment = document.createDocumentFragment();
  for (let index = 0; index < 12; index += 1) {
    const star = document.createElement("i");
    star.className = "star";
    star.style.left = `${7 + Math.random() * 86}%`;
    star.style.top = `${8 + Math.random() * 84}%`;
    star.style.opacity = `${0.22 + Math.random() * 0.45}`;
    fragment.appendChild(star);
  }
  container.appendChild(fragment);
}

function handleKeyDown(event) {
  if (!state.gameVisible) return;
  if (event.code === "Space") {
    event.preventDefault();
    if (!state.spaceDown && !event.repeat) {
      state.spaceDown = true;
      catchPlayer();
    }
    return;
  }
  if (event.code === "Backspace") {
    event.preventDefault();
    if (!event.repeat) undoCatch();
    return;
  }
  if (event.code === "KeyP") {
    event.preventDefault();
    if (!event.repeat) togglePause();
    return;
  }
  if (event.code === "Escape") {
    event.preventDefault();
    exitGame();
    return;
  }
  if (event.code === "Enter" && state.ended) {
    event.preventDefault();
    exitGame();
  }
}

function bindEvents() {
  els.modeButtons.forEach((button) => {
    button.addEventListener("click", () => {
      selectMode(button.dataset.mode);
      updateFormSummary();
    });
  });

  [els.hours, els.minutes, els.seconds, els.players, els.volume].forEach((input) => {
    input.addEventListener("input", updateFormSummary);
    input.addEventListener("change", updateFormSummary);
  });
  els.shuffle.addEventListener("change", updateFormSummary);
  els.effects.addEventListener("change", updateFormSummary);
  els.playerMinus.addEventListener("click", () => {
    els.players.value = Math.max(
      1,
      clamp(els.players.value, 1, 999, 1) - 1,
    );
    updateFormSummary();
  });
  els.playerPlus.addEventListener("click", () => {
    els.players.value = Math.min(
      999,
      clamp(els.players.value, 1, 999, 1) + 1,
    );
    updateFormSummary();
  });
  els.addMusic.addEventListener("click", chooseMusic);
  els.start.addEventListener("click", startGame);
  els.endBack.addEventListener("click", exitGame);
  window.addEventListener("keydown", handleKeyDown, true);
  window.addEventListener("keyup", (event) => {
    if (event.code === "Space") state.spaceDown = false;
  });
  window.addEventListener("blur", () => {
    state.spaceDown = false;
  });
  window.addEventListener("contextmenu", (event) => event.preventDefault());
}

async function initialize() {
  if (document.body.dataset.initialized === "true") return;
  document.body.dataset.initialized = "true";
  createStars();
  bindEvents();
  applySettings(defaults);

  if (hasBridge()) {
    const result = await apiCall("load_settings", [], {
      timeout: 4000,
      warn: true,
    });
    if (result.ok) applySettings(result.value || defaults);
  }
}

window.addEventListener("pywebviewready", initialize, { once: true });
window.setTimeout(initialize, 650);
