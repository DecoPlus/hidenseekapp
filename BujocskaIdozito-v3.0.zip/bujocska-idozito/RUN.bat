@echo off
setlocal
cd /d "%~dp0"

set "PY_CMD=py -3"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=python"

%PY_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo A futtatashoz Python 3 szukseges:
    echo https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)

echo A szukseges csomagok ellenorzese...
%PY_CMD% -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 (
    echo A csomagok telepitese nem sikerult.
    pause
    exit /b 1
)

%PY_CMD% app.py
if errorlevel 1 pause
