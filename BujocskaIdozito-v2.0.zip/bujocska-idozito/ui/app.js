"use strict";

const $ = (selector) => document.querySelector(selector);

const els = {
  adminScreen: $("#adminScreen"),
  gameScreen: $("#gameScreen"),
  hours: $("#hoursInput"),
  minutes: $("#minutesInput"),
  seconds: $("#secondsInput"),
  players: $("#playersInput"),
  shuffle: $("#shuffleInput"),
  volume: $("#volumeInput"),
  volumeValue: $("#volumeValue"),
  playlist: $("#playlist"),
  playlistEmpty: $("#playlistEmpty"),
  addMusic: $("#addMusicButton"),
  playerMinus: $("#playerMinus"),
  playerPlus: $("#playerPlus"),
  start: $("#startButton"),
  summary: $("#launchSummary"),
  error: $("#formError"),
  timer: $("#timerDisplay"),
  progress: $("#progressBar"),
  alive: $("#aliveCount"),
  aliveCard: $("#aliveCard"),
  captureFlash: $("#captureFlash"),
  captureToast: $("#captureToast"),
  intro: $("#introOverlay"),
  introCount: $("#introCount"),
  pause: $("#pauseOverlay"),
  end: $("#endOverlay"),
  endTitle: $("#endTitle"),
  endSubtitle: $("#endSubtitle"),
  endBack: $("#endBackButton"),
};

const defaults = {
  hours: 0,
  minutes: 10,
  seconds: 59,
  players: 12,
  shuffle: false,
  volume: 80,
  music: [],
};

const state = {
  settings: { ...defaults },
  playlist: [],
  durationMs: 0,
  remainingMs: 0,
  deadline: 0,
  totalPlayers: 12,
  alivePlayers: 12,
  running: false,
  paused: false,
  ended: false,
  gameVisible: false,
  spaceDown: false,
  frame: 0,
  lastShownSecond: null,
  introToken: 0,
};

function hasBridge() {
  return Boolean(window.pywebview && window.pywebview.api);
}

async function apiCall(method, ...args) {
  if (!hasBridge() || typeof window.pywebview.api[method] !== "function") {
    return null;
  }
  try {
    return await window.pywebview.api[method](...args);
  } catch (error) {
    console.error(`API hiba (${method})`, error);
    return null;
  }
}

function clamp(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function baseName(path) {
  return String(path).split(/[\\/]/).pop() || path;
}

function formatTime(milliseconds) {
  const totalSeconds = Math.max(0, Math.ceil(milliseconds / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) {
    return [hours, minutes, seconds]
      .map((value) => String(value).padStart(2, "0"))
      .join(":");
  }
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function readForm() {
  const settings = {
    hours: clamp(els.hours.value, 0, 23, 0),
    minutes: clamp(els.minutes.value, 0, 59, 0),
    seconds: clamp(els.seconds.value, 0, 59, 0),
    players: clamp(els.players.value, 1, 999, 1),
    shuffle: els.shuffle.checked,
    volume: clamp(els.volume.value, 0, 100, 80),
    music: [...state.playlist],
  };
  settings.duration =
    settings.hours * 3600 + settings.minutes * 60 + settings.seconds;
  return settings;
}

function applySettings(settings) {
  const clean = { ...defaults, ...(settings || {}) };
  els.hours.value = clamp(clean.hours, 0, 23, 0);
  els.minutes.value = clamp(clean.minutes, 0, 59, 10);
  els.seconds.value = clamp(clean.seconds, 0, 59, 59);
  els.players.value = clamp(clean.players, 1, 999, 12);
  els.shuffle.checked = Boolean(clean.shuffle);
  els.volume.value = clamp(clean.volume, 0, 100, 80);
  state.playlist = Array.isArray(clean.music)
    ? [...new Set(clean.music.filter((item) => typeof item === "string" && item))]
    : [];
  renderPlaylist();
  updateFormSummary();
}

function showError(message) {
  els.error.textContent = message;
  els.error.classList.toggle("visible", Boolean(message));
}

function updateFormSummary() {
  const settings = readForm();
  els.hours.value = settings.hours;
  els.minutes.value = settings.minutes;
  els.seconds.value = settings.seconds;
  els.players.value = settings.players;
  els.volumeValue.textContent = `${settings.volume}%`;
  els.summary.textContent = `${formatTime(settings.duration * 1000)} • ${settings.players} játékos`;
  if (settings.duration > 0) showError("");
}

function iconButton(icon, label, className, handler) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = className || "";
  button.title = label;
  button.setAttribute("aria-label", label);
  button.innerHTML = icon;
  button.addEventListener("click", handler);
  return button;
}

function renderPlaylist() {
  els.playlist.replaceChildren();
  if (state.playlist.length === 0) {
    els.playlist.appendChild(els.playlistEmpty);
    els.playlistEmpty.hidden = false;
    return;
  }

  state.playlist.forEach((path, index) => {
    const row = document.createElement("div");
    row.className = "playlist-row";
    row.style.animationDelay = `${Math.min(index * 35, 210)}ms`;

    const number = document.createElement("span");
    number.className = "playlist-index";
    number.textContent = String(index + 1).padStart(2, "0");

    const name = document.createElement("span");
    name.className = "playlist-name";
    name.textContent = baseName(path);
    name.title = path;

    const actions = document.createElement("div");
    actions.className = "playlist-actions";
    const up = iconButton(
      '<svg viewBox="0 0 24 24"><path d="m6 15 6-6 6 6"></path></svg>',
      "Feljebb",
      "",
      () => moveTrack(index, -1),
    );
    const down = iconButton(
      '<svg viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"></path></svg>',
      "Lejjebb",
      "",
      () => moveTrack(index, 1),
    );
    const remove = iconButton(
      '<svg viewBox="0 0 24 24"><path d="M5 5l14 14M19 5 5 19"></path></svg>',
      "Eltávolítás",
      "remove",
      () => removeTrack(index),
    );
    up.disabled = index === 0;
    down.disabled = index === state.playlist.length - 1;
    actions.append(up, down, remove);
    row.append(number, name, actions);
    els.playlist.appendChild(row);
  });
}

function moveTrack(index, direction) {
  const target = index + direction;
  if (target < 0 || target >= state.playlist.length) return;
  [state.playlist[index], state.playlist[target]] = [
    state.playlist[target],
    state.playlist[index],
  ];
  renderPlaylist();
}

function removeTrack(index) {
  state.playlist.splice(index, 1);
  renderPlaylist();
}

async function chooseMusic() {
  els.addMusic.disabled = true;
  const selected = await apiCall("choose_music");
  els.addMusic.disabled = false;
  if (!Array.isArray(selected) || selected.length === 0) return;
  state.playlist = [...new Set([...state.playlist, ...selected])];
  renderPlaylist();
}

function switchScreen(target) {
  [els.adminScreen, els.gameScreen].forEach((screen) => {
    screen.classList.toggle("active", screen === target);
  });
  state.gameVisible = target === els.gameScreen;
}

function wait(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

async function playIntro() {
  const token = ++state.introToken;
  els.intro.classList.add("active");
  els.intro.setAttribute("aria-hidden", "false");
  const frames = [
    ["3", 620],
    ["2", 620],
    ["1", 620],
    ["INDULJ!", 720],
  ];
  for (const [text, duration] of frames) {
    if (token !== state.introToken) return false;
    els.introCount.textContent = text;
    els.introCount.classList.remove("pop");
    void els.introCount.offsetWidth;
    els.introCount.classList.add("pop");
    await wait(duration);
  }
  if (token !== state.introToken) return false;
  els.intro.classList.remove("active");
  els.intro.setAttribute("aria-hidden", "true");
  return true;
}

async function startGame() {
  const settings = readForm();
  if (settings.duration <= 0) {
    showError("A játékidő nem lehet 00:00.");
    return;
  }
  showError("");
  els.start.disabled = true;

  const saved = await apiCall("prepare_session", settings);
  state.settings = saved || settings;
  state.durationMs = settings.duration * 1000;
  state.remainingMs = state.durationMs;
  state.totalPlayers = settings.players;
  state.alivePlayers = settings.players;
  state.running = false;
  state.paused = false;
  state.ended = false;
  state.spaceDown = false;
  state.lastShownSecond = null;

  els.timer.textContent = formatTime(state.durationMs);
  els.progress.style.transform = "scaleX(1)";
  els.alive.textContent = String(state.alivePlayers);
  els.end.classList.remove("active");
  els.pause.classList.remove("active");
  switchScreen(els.gameScreen);

  const introFinished = await playIntro();
  els.start.disabled = false;
  if (!introFinished || !state.gameVisible) return;

  await apiCall("start_music");
  state.deadline = performance.now() + state.durationMs;
  state.running = true;
  state.frame = requestAnimationFrame(gameLoop);
}

function gameLoop(now) {
  if (!state.gameVisible) return;
  if (state.running && !state.paused && !state.ended) {
    state.remainingMs = Math.max(0, state.deadline - now);
    renderGameTime();
    if (state.remainingMs <= 0) {
      finishGame("time");
      return;
    }
  }
  state.frame = requestAnimationFrame(gameLoop);
}

function renderGameTime() {
  const shown = Math.max(0, Math.ceil(state.remainingMs / 1000));
  els.timer.textContent = formatTime(state.remainingMs);
  els.progress.style.transform = `scaleX(${Math.max(
    0,
    Math.min(1, state.remainingMs / state.durationMs),
  )})`;
  if (state.lastShownSecond !== shown) {
    state.lastShownSecond = shown;
    els.timer.classList.remove("tick");
    void els.timer.offsetWidth;
    els.timer.classList.add("tick");
  }
}

function animateCapture() {
  els.alive.classList.remove("bump");
  els.aliveCard.classList.remove("hit");
  els.captureFlash.classList.remove("active");
  els.captureToast.classList.remove("show");
  void els.alive.offsetWidth;
  els.alive.classList.add("bump");
  els.aliveCard.classList.add("hit");
  els.captureFlash.classList.add("active");
  els.captureToast.classList.add("show");
}

function catchPlayer() {
  if (!state.running || state.paused || state.ended || state.alivePlayers <= 0) {
    return;
  }
  state.alivePlayers -= 1;
  els.alive.textContent = String(state.alivePlayers);
  animateCapture();
  if (state.alivePlayers <= 0) {
    window.setTimeout(() => finishGame("caught"), 300);
  }
}

function undoCatch() {
  if (
    !state.running ||
    state.paused ||
    state.ended ||
    state.alivePlayers >= state.totalPlayers
  ) {
    return;
  }
  state.alivePlayers += 1;
  els.alive.textContent = String(state.alivePlayers);
  els.alive.animate(
    [
      { transform: "translateY(7px)", color: "#6ce8a7", opacity: 0.5 },
      { transform: "translateY(0)", color: "#f8f6f3", opacity: 1 },
    ],
    { duration: 360, easing: "cubic-bezier(.2,.8,.2,1)" },
  );
}

async function togglePause() {
  if (!state.running || state.ended) return;
  if (state.paused) {
    state.paused = false;
    state.deadline = performance.now() + state.remainingMs;
    els.pause.classList.remove("active");
    els.pause.setAttribute("aria-hidden", "true");
    await apiCall("resume_music");
  } else {
    state.remainingMs = Math.max(0, state.deadline - performance.now());
    state.paused = true;
    els.pause.classList.add("active");
    els.pause.setAttribute("aria-hidden", "false");
    await apiCall("pause_music");
  }
}

async function finishGame(reason) {
  if (state.ended) return;
  state.running = false;
  state.paused = false;
  state.ended = true;
  cancelAnimationFrame(state.frame);
  await apiCall("finish_music");

  if (reason === "caught") {
    els.endTitle.textContent = "MINDENKI KIESETT.";
    els.endSubtitle.textContent = `${formatTime(state.remainingMs)} maradt az órán.`;
  } else {
    els.endTitle.textContent = "LEJÁRT AZ IDŐ.";
    if (state.alivePlayers === 1) {
      els.endSubtitle.textContent = "1 játékos maradt életben.";
    } else {
      els.endSubtitle.textContent = `${state.alivePlayers} játékos maradt életben.`;
    }
  }
  els.end.classList.add("active");
  els.end.setAttribute("aria-hidden", "false");
}

async function exitGame() {
  if (!state.gameVisible) return;
  ++state.introToken;
  state.running = false;
  state.paused = false;
  state.ended = false;
  state.spaceDown = false;
  cancelAnimationFrame(state.frame);
  [els.intro, els.pause, els.end].forEach((overlay) => {
    overlay.classList.remove("active");
    overlay.setAttribute("aria-hidden", "true");
  });
  switchScreen(els.adminScreen);
  await apiCall("exit_session");
}

function createStars() {
  const container = $("#stars");
  const fragment = document.createDocumentFragment();
  for (let index = 0; index < 28; index += 1) {
    const star = document.createElement("i");
    star.className = "star";
    star.style.left = `${5 + Math.random() * 90}%`;
    star.style.top = `${8 + Math.random() * 82}%`;
    star.style.setProperty("--twinkle", `${2.8 + Math.random() * 4}s`);
    star.style.setProperty("--delay", `${Math.random() * -5}s`);
    if (Math.random() > 0.75) {
      star.style.width = "2px";
      star.style.height = "2px";
    }
    fragment.appendChild(star);
  }
  container.appendChild(fragment);
}

function handleKeyDown(event) {
  if (!state.gameVisible) return;
  if (event.code === "Space") {
    event.preventDefault();
    if (!state.spaceDown && !event.repeat) {
      state.spaceDown = true;
      catchPlayer();
    }
    return;
  }
  if (event.code === "Backspace") {
    event.preventDefault();
    if (!event.repeat) undoCatch();
    return;
  }
  if (event.code === "KeyP") {
    event.preventDefault();
    if (!event.repeat) togglePause();
    return;
  }
  if (event.code === "Escape") {
    event.preventDefault();
    exitGame();
    return;
  }
  if (event.code === "Enter" && state.ended) {
    event.preventDefault();
    exitGame();
  }
}

function bindEvents() {
  [els.hours, els.minutes, els.seconds, els.players, els.volume].forEach((input) => {
    input.addEventListener("input", updateFormSummary);
    input.addEventListener("change", updateFormSummary);
  });
  els.shuffle.addEventListener("change", updateFormSummary);
  els.playerMinus.addEventListener("click", () => {
    els.players.value = clamp(els.players.value, 1, 999, 1) - 1;
    if (Number(els.players.value) < 1) els.players.value = 1;
    updateFormSummary();
  });
  els.playerPlus.addEventListener("click", () => {
    els.players.value = clamp(els.players.value, 1, 999, 1) + 1;
    if (Number(els.players.value) > 999) els.players.value = 999;
    updateFormSummary();
  });
  els.addMusic.addEventListener("click", chooseMusic);
  els.start.addEventListener("click", startGame);
  els.endBack.addEventListener("click", exitGame);
  window.addEventListener("keydown", handleKeyDown, true);
  window.addEventListener("keyup", (event) => {
    if (event.code === "Space") state.spaceDown = false;
  });
  window.addEventListener("blur", () => {
    state.spaceDown = false;
  });
  window.addEventListener("contextmenu", (event) => event.preventDefault());
}

async function initialize() {
  if (document.body.dataset.initialized === "true") return;
  document.body.dataset.initialized = "true";
  createStars();
  bindEvents();
  updateFormSummary();
  if (hasBridge()) {
    const settings = await apiCall("load_settings");
    applySettings(settings || defaults);
  } else {
    applySettings(defaults);
  }
}

if (window.pywebview && window.pywebview.api) {
  initialize();
} else {
  window.addEventListener("pywebviewready", initialize, { once: true });
  window.setTimeout(() => {
    if (!document.body.dataset.initialized) initialize();
  }, 700);
}
